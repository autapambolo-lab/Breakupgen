# BreakUpGen (Python + Flask)

A small mobile-friendly breakup-message generator built with Python and Flask.

## Run locally

1. Install Python 3.10+.
2. In this folder, run `pip install -r requirements.txt`.
3. Run `python app.py`.
4. Open the local address printed in the terminal.

## Free hosting

Upload these files to a Git repository and choose a free Python-compatible host that currently offers a free web service. Free hosting policies, sleep behavior, and usage limits can change, so check the host's current plan before deploying.

This starter project does not include accounts, analytics, or a database.
