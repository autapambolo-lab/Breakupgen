from flask import Flask, render_template, request
import random

app = Flask(__name__)

MESSAGES = {
    "cheating": {
        "soft": [
            "I care about what we shared, but the trust between us has been broken. I need to step away from this relationship and choose peace for myself. I wish you well, but I think it is best that we say goodbye.",
            "This is difficult to say, but what happened has changed how I feel in this relationship. I cannot rebuild things the way they were, so I need to end this respectfully. I hope we both find a healthier path forward."
        ],
        "emotional": [
            "I never imagined that we would reach this point. I gave this relationship my trust, and what happened hurt me deeply. I still have feelings about what we shared, but I cannot ignore the pain. I need to let go and move forward.",
            "The hardest part is not just what happened, but how it changed the way I see us. I wanted honesty and loyalty, and now I need to protect my heart. I am choosing to leave, even though it hurts."
        ],
        "cold": [
            "The trust is gone, and I am ending this relationship. I will not continue something that no longer feels right for me. Please respect my decision.",
            "Your choice changed this relationship. I am done, and my decision is final. I wish you well, but I am moving on."
        ],
        "funny": [
            "This relationship has officially lost its membership benefits. The trust subscription expired, and I will not be renewing it. I wish you luck on your next chapter.",
            "I came for love, not a plot twist. This season is over, and I am cancelling the next episode. Take care."
        ],
    },
    "lost_feelings": {
        "soft": [
            "You matter to me, and that is why I want to be honest. My feelings have changed, and it would not be fair to pretend otherwise. I think we should end the relationship with respect and give each other room to move forward.",
            "I appreciate the moments we shared, but I no longer feel the connection a relationship needs. You deserve someone who can love you wholeheartedly, and I need to be honest about where I am emotionally."
        ],
        "emotional": [
            "I wish feelings came with an instruction manual, because I never wanted to hurt you. But something has changed in me, and pretending would only hurt us more in the long run. I will always value what we shared, even as I let go.",
            "This is painful because you have been part of my life and my memories. I cannot force feelings that are no longer there. I think we need to say goodbye, even if it takes time to understand why."
        ],
        "cold": [
            "My feelings have changed, and I do not want to continue this relationship. I am being honest rather than pretending. I wish you the best.",
            "I no longer feel the connection I need in this relationship. I am ending things here. Please respect my decision."
        ],
        "funny": [
            "My heart has submitted its resignation letter, and unfortunately there is no replacement available. I think it is best we end things respectfully. Take care.",
            "The romantic Wi-Fi is no longer connecting, and restarting the router has not helped. I think we should call it here and move forward separately."
        ],
    },
}

@app.route("/", methods=["GET", "POST"])
def home():
    message = None
    if request.method == "POST":
        reason = request.form.get("reason", "lost_feelings")
        tone = request.form.get("tone", "soft")
        pronoun = request.form.get("pronoun", "they")

        # Validate submitted choices rather than trusting arbitrary form values.
        if reason not in MESSAGES:
            reason = "lost_feelings"
        if tone not in MESSAGES[reason]:
            tone = "soft"

        message = random.choice(MESSAGES[reason][tone])
        if pronoun == "she":
            message = message.replace("they", "she").replace("them", "her")
        elif pronoun == "he":
            message = message.replace("they", "he").replace("them", "him")

    return render_template("index.html", message=message)

if __name__ == "__main__":
    app.run(debug=True)
